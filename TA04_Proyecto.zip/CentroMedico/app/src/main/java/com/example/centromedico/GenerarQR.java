package com.example.centromedico;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GenerarQR extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generar_qr);
    }
}