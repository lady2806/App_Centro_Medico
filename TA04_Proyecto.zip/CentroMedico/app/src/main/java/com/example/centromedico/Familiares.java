package com.example.centromedico;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Familiares extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_familiares);
    }
}