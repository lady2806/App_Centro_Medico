package com.example.centromedico;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class PortadaOficial extends AppCompatActivity {

    CardView InfoPer;
    CardView CentrosTele;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_portada_oficial);

        InfoPer = (CardView) findViewById(R.id.InfoPer);

        InfoPer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PortadaOficial.this, InformacionPersonal.class);
                PortadaOficial.this.startActivity(intent);
            }
        });

        CentrosTele = (CardView) findViewById(R.id.CentrosTele);

        CentrosTele.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentReg = new Intent(PortadaOficial.this, CentrosTelefonicos.class);
                PortadaOficial.this.startActivity(intentReg);
            }
        });




    }
}